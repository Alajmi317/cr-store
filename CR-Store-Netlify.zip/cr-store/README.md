# CR Store

Digital FiveM store. Brand identity uses the original CR Store logo at public/brand/logo.png with no edits.

## Stack
Next.js 15, TypeScript, Tailwind 4, PostgreSQL, Prisma, Stripe, PayPal, SMTP, Discord webhooks.

## 1. Run
cd cr-store
cp .env.example .env
# edit .env
npm install
npx prisma generate
npx prisma db push
npx tsx prisma/seed.ts
npm run dev

Open http://localhost:3000

## 2. Database
Set DATABASE_URL to PostgreSQL then:
npx prisma generate
npx prisma db push
# or
npx prisma migrate dev --name init

## 3. First Owner
Seed uses OWNER_EMAIL / OWNER_PASSWORD / OWNER_NAME from .env. Login at /login.

## 4. Environment variables
See .env.example

DATABASE_URL
NEXT_PUBLIC_APP_URL
AUTH_SECRET
STRIPE_SECRET_KEY
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
STRIPE_WEBHOOK_SECRET
PAYPAL_CLIENT_ID
PAYPAL_CLIENT_SECRET
PAYPAL_MODE
SMTP_HOST SMTP_PORT SMTP_USER SMTP_PASS SMTP_FROM
DISCORD_WEBHOOK_URL
STORAGE_DIR
OWNER_EMAIL OWNER_PASSWORD OWNER_NAME

## 5. Stripe
Add secret + publishable keys.
Webhook URL: https://YOUR_DOMAIN/api/webhooks/stripe
Event: checkout.session.completed
Orders become PAID only after webhook verification. The browser never marks an order paid.

## 6. Apple Pay
Enable Apple Pay in the Stripe Dashboard and verify your domain. Customers then see Apple Pay inside Stripe Checkout.

## 7. PayPal
Create an app in the PayPal developer dashboard.
Set PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_MODE=sandbox or live.

## 8. Discord
Create a channel webhook and set DISCORD_WEBHOOK_URL.
Used for paid orders, new tickets, closed tickets.

## 9. Digital product files
Admin > Products > save product > upload zip.
Files are stored under storage/products, not inside public/.
After a verified payment the customer gets /api/downloads/[token] in Account > Downloads.
Downloads are bound to user + order, have remaining counts, and can be disabled.

## 10. Production
Set all env vars on the host.
npm run build && npm start
Use a real PostgreSQL instance.
Local disk storage is fine on a VPS. On serverless hosts use object storage.
Never put secret keys in client code.

## Implemented
Home, Store, Categories, Search, Product details, Cart, Checkout, Success
Auth (register, login, logout, forgot, reset, verify)
Roles: Customer, Support, Admin, Owner
Orders, Downloads, Tickets
Admin dashboard, products, orders, users, tickets, analytics, settings, payments
Stripe + PayPal server flows + webhook signature check
SEO metadata, sitemap, robots, JSON-LD
AR/EN with RTL/LTR
CR Store logo and dark metallic theme
